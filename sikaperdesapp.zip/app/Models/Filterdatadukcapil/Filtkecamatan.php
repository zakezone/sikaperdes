<?php

namespace App\Models\Filterdatadukcapil;

use CodeIgniter\Model;

class Filtkecamatan extends Model
{
    protected $table = 'sikaperdes_filt_kecamatan_dispermadesdukcapil';
}
