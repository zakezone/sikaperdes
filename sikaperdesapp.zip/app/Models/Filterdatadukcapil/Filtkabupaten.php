<?php

namespace App\Models\Filterdatadukcapil;

use CodeIgniter\Model;

class Filtkabupaten extends Model
{
    protected $table = 'sikaperdes_filt_kabupaten_dispermadesdukcapil';
}
