<?php

namespace App\Models\Filterdatadukcapil;

use CodeIgniter\Model;

class Filtkeldesa extends Model
{
    protected $table = 'sikaperdes_filt_keldesa_dispermadesdukcapil';
}
