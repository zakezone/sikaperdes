/**
 * @license Highcharts JS v8.2.2 (2020-10-22)
 * @module highcharts/modules/drilldown
 * @requires highcharts
 *
 * Highcharts Drilldown module
 *
 * Author: Torstein Honsi
 * License: www.highcharts.com/license
 *
 */
'use strict';
import '../../Extensions/Drilldown.js';
