/**
 * @license Highcharts JS v8.2.2 (2020-10-22)
 * @module highcharts/themes/sunset
 * @requires highcharts
 *
 * (c) 2009-2019 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/Themes/Sunset.js';
